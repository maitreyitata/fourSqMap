(function(){
angular.module('searchApp', ['ui.bootstrap'])
.controller('mainController',['$scope','$http',function($scope,$http){
	$scope.searchInp = "";
	$scope.items = [];
	$scope.markers = [];
	$scope.words = ["Coffee","food","Pizzas"];
	$scope.searchInp = undefined; $scope.location = undefined;
	$scope.sections = ["food","drinks", "coffee", "shops", "arts", "outdoors", "sights", "trending","specials", "nextVenues"]
	$scope.search = function(searchInp){
		var location = document.getElementById('searchLoc').value;
		$scope.fsClientId = 'WMY4CXUC1SUEEHMYZLHKA1AR3AYIGU5RS0KFXJG4MBSWSKMP';
		$scope.fsClientSecret = 'XZJAAF5STXHGQSHA0YPQLJXE1KYTSNNLO2RSSWCCW2D04OWY';
		$scope.googlekey = 'AIzaSyBzvuXABLKwbC_QB4yvtSOLTK0Gcb64kNs';
		if($scope.sections.indexOf(searchInp) > -1){
			var url = "https://api.foursquare.com/v2/venues/explore/?near="+location+ "&section=" + searchInp+ "&venuePhotos=1"+"&client_id=" + $scope.fsClientId +
			    "&client_secret=" + $scope.fsClientSecret +
			    " &v=20131124"
		}else{
			var url = "https://api.foursquare.com/v2/venues/explore/?near="+location+ "&query=" + searchInp+ "&venuePhotos=1"+"&client_id=" + $scope.fsClientId +
			    "&client_secret=" + $scope.fsClientSecret +
			    " &v=20131124"
		}
		$http.get( url).then(function(result,status){
	  	$scope.items = result.data.response.groups[0].items;
	  	$scope.geoCode = result.data.response.geocode.center;
	  	drawMap($scope.geoCode,$scope.items,$scope);
	  
  });
	};

	$scope.mapInfo = function(index,address){
		google.maps.event.trigger($scope.markers[index], 'click');
	};
}]);

function drawMap(geoCode,items,scope){
	 var mapOptions = {
    	zoom: 50,
    	maxZoom: 12,
    	center: new google.maps.LatLng(geoCode.lat, geoCode.lng),
    	mapTypeId: google.maps.MapTypeId.ROADMAP
  }
  		var map = new google.maps.Map(document.getElementById("map"),
                                mapOptions);

   setMarkers(map, items,scope.markers);
}

function setMarkers(map,items,markers){
	var image = 'images/marker.png';
	for (var i = 0; i < items.length; i++) {
	    var location = items[i].venue.location;
	    var myLatLng = new google.maps.LatLng(location.lat, location.lng);
	    markers[i] = new google.maps.Marker({
        position: myLatLng,
        map: map,
        title: location.name,
        label: ""+i
		});
		(function(marker,i){
                google.maps.event.addListener(marker, 'click', function(){ 
                var infowindow = new google.maps.InfoWindow();
                infowindow.close(); // Close previously opened infowindow
        		infowindow.setContent( "<div id='infowindow'>"+ items[i].venue.location.formattedAddress[0] +"</div>");
        		infowindow.open(map, this);
                //infowindow.open(map,this);
                }); 
            }(markers[i],i));
        
	  }
}
	var input = document.getElementById('searchLoc');
	var autocomplete = new google.maps.places.Autocomplete(input);
})();